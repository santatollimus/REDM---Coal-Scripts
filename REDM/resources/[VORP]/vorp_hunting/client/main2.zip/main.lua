-- Mercy + Skin
local INTERACTION_ANIMAL_SKIN = joaat("INTERACTION_ANIMAL_SKIN")

-- Mercy Kill control hash (copied from vorp_stables/keys.lua)
local CONTROL_MERCYKILL = 0x956C2A0E

-- Find the closest injured animal near the player within a radius (in meters)
local function GetClosestInjuredAnimal(ped, radius)
    local px, py, pz = table.unpack(GetEntityCoords(ped))
    local bestPed = 0
    local bestDistSq = radius * radius

    for _, candidate in ipairs(GetGamePool("CPed")) do
        if candidate ~= ped and DoesEntityExist(candidate) then
            if not IsPedHuman(candidate) then
                -- Must be fatally injured (true mercy state)
                if IsPedFatallyInjured(candidate) and not IsEntityDead(candidate) then
                    local cx, cy, cz = table.unpack(GetEntityCoords(candidate))
                    local dx, dy, dz = cx - px, cy - py, cz - pz
                    local distSq = dx * dx + dy * dy + dz * dz

                    if distSq <= bestDistSq then
                        bestDistSq = distSq
                        bestPed = candidate
                    end
                end
            end
        end
    end

    return bestPed
end

-- Mercy + Skin prompt thread
CreateThread(function()
    repeat Wait(1000) until LocalPlayer.state.IsInSession

    -- create prompt bound to Mercy Kill control
    local mercyPrompt = PromptRegisterBegin()
    PromptSetControlAction(mercyPrompt, CONTROL_MERCYKILL)

    local str = CreateVarString(10, "LITERAL_STRING", "Mercy + Skin")
    PromptSetText(mercyPrompt, str)

    -- start hidden & disabled
    PromptSetEnabled(mercyPrompt, false)
    PromptSetVisible(mercyPrompt, false)

    -- TAP mode only
    PromptSetStandardMode(mercyPrompt, true)
    -- no hold mode, no prompt group here

    PromptRegisterEnd(mercyPrompt)

    local promptShown = false

    while true do
        Wait(0)

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsEntityDead(ped) then
            goto continue_loop
        end

        local target = GetClosestInjuredAnimal(ped, 2.0)

        if target ~= 0 then
            -- show prompt when a valid injured animal is nearby
            if not promptShown then
                PromptSetEnabled(mercyPrompt, true)
                PromptSetVisible(mercyPrompt, true)
                promptShown = true
                print("[Mercy+Skin] Prompt shown")
            end

            -- tap Mercy Kill key
            if Citizen.InvokeNative(0xC92AC953F0A982AE, mercyPrompt) then
                print("[Mercy+Skin] Prompt completed, target:", target)

                -- finish the animal
                ApplyDamageToPed(target, 1000.0, true, 0, false, true, false, false)

                -- start skinning after a short delay
                CreateThread(function()
                    Wait(1500)
                    if DoesEntityExist(target) then
                        print("[Mercy+Skin] Starting skin interaction on", target)
                        Citizen.InvokeNative(
                            0xCD181A959CFDD7F4,  -- TASK_ANIMAL_INTERACTION
                            ped,
                            target,
                            INTERACTION_ANIMAL_SKIN,
                            0,
                            0
                        )
                    else
                        print("[Mercy+Skin] Target no longer exists")
                    end
                end)
            end
        else
            -- no valid target: hide prompt entirely
            if promptShown then
                PromptSetEnabled(mercyPrompt, false)
                PromptSetVisible(mercyPrompt, false)
                promptShown = false
                print("[Mercy+Skin] Prompt hidden (no target)")
            end
        end

        ::continue_loop::
    end
end)
